# Universe Programming Language

**By Youcef Dev**

Universe is a modern programming language designed for simplicity, speed, and power.  
You can write `.uni` scripts easily and build applications efficiently.

---

## Features
- AOT Compilation (Universe → Machine code)
- Modern syntax, easy to learn
- Powerful standard library
- Cross-platform support

---

## Getting Started
1. Include universe.exe in system variables "path"
2. Open terminal / command prompt  
3. Run scripts:

```bash
universe run main.uni

```
```
say("hello world");
```